import java.util.TreeMap;

public class Ut6_3  {

    TreeMap treeMap = new TreeMap();
}
